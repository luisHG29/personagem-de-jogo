<?php
    //Redireciona para a listagem de alunos
    header("location: ./view/personagem/listar.php");
    