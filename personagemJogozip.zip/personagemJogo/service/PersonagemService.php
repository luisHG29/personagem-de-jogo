<?php

include_once(__DIR__ . "/../model/Personagem.php");

class PersonagemService
{

    public function validarDados(Personagem $personagem)
    {

        $erros = array();

        if (! $personagem->getNome())
            array_push($erros, "Informe o nome!");

        if (! $personagem->getIdade())
            array_push($erros, "Informe a idade!");

        if (! $personagem->getAltura())
            array_push($erros, "Informe a altura!");

        if (! $personagem->getPeso())
            array_push($erros, "Informe o peso!");

        if (! $personagem->getHabilidade())
            array_push($erros, "Informe a habilidade!");

        if (! $personagem->getAcessorio())
            array_push($erros, "Informe o acessório!");

        if (! $personagem->getUniverso())
            array_push($erros, "Informe o universo!");

        return $erros;
    }
}
