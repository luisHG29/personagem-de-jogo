<?php

include_once(__DIR__ . "/../dao/AcessorioDao.php");

class AcessorioController {

    public function listar() {
        $acessorioDao = new AcessorioDao();

        return $acessorioDao->list();
    }

}