<?php

include_once(__DIR__ . "/../dao/PersonagemDao.php");
include_once(__DIR__ . "/../service/PersonagemService.php");

class PersonagemController {

    public function listar() {
        $personagemDao = new PersonagemDao();
        
        $personagens = $personagemDao->list();
        return $personagens;
    }

    public function buscarPorId($idFilme) {
        $personagemDao = new PersonagemDao();

        $filme = $personagemDao->findById($idFilme);
        return $filme;
    }

    public function inserir($filme) {
        $PersonagemService = new PersonagemService();
        $erros = $PersonagemService->validarDados($filme);

        if(count($erros) > 0)
            return $erros;

        $personagemDao = new PersonagemDao();
        $personagemDao->insert($filme);
        return array();
    }

    public function alterar($filme) {
        $PersonagemService = new PersonagemService();
        $erros = $PersonagemService->validarDados($filme);

        if(count($erros) > 0)
            return $erros;

        $personagemDao = new PersonagemDao();
        $personagemDao->update($filme);
        return array();
    }

    public function excluir($id) {
        $personagemDao = new PersonagemDao();

        $personagemDao->delete($id);
    }

}