<?php

include_once(__DIR__ . "/../dao/UniversoDao.php");

class UniversoController {

    public function listar() {
        $universoDao = new UniversoDao();

        return $universoDao->list();
    }

}