<?php

include_once(__DIR__ . "/../dao/HabilidadeDao.php");

class HabilidadeController {

    public function listar() {
        $habilidadeDao = new HabilidadeDao();

        return $habilidadeDao->list();
    }

}