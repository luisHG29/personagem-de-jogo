<?php

include_once(__DIR__ . "/Habilidade.php");
include_once(__DIR__ . "/Acessorio.php");
include_once(__DIR__ . "/Universo.php");

class Personagem {

    private ?int $id;
    private ?string $nome;
    private ?int $idade;
    private ?int $altura;
    private ?int $peso;
    private ?Habilidade $habilidade;
    private ?Acessorio $acessorio;
    private ?Universo $universo;
    

  

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */ 
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     *
     * @return  self
     */ 
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of idade
     */ 
    public function getIdade()
    {
        return $this->idade;
    }

    /**
     * Set the value of idade
     *
     * @return  self
     */ 
    public function setIdade($idade)
    {
        $this->idade = $idade;

        return $this;
    }

    /**
     * Get the value of altura
     */ 
    public function getAltura()
    {
        return $this->altura;
    }

    /**
     * Set the value of altura
     *
     * @return  self
     */ 
    public function setAltura($altura)
    {
        $this->altura = $altura;

        return $this;
    }

    /**
     * Get the value of peso
     */ 
    public function getPeso()
    {
        return $this->peso;
    }

    /**
     * Set the value of peso
     *
     * @return  self
     */ 
    public function setPeso($peso)
    {
        $this->peso = $peso;

        return $this;
    }

    /**
     * Get the value of habilidade
     */ 
    public function getHabilidade()
    {
        return $this->habilidade;
    }

    /**
     * Set the value of habilidade
     *
     * @return  self
     */ 
    public function setHabilidade($habilidade)
    {
        $this->habilidade = $habilidade;

        return $this;
    }

    /**
     * Get the value of acessorio
     */ 
    public function getAcessorio()
    {
        return $this->acessorio;
    }

    /**
     * Set the value of acessorio
     *
     * @return  self
     */ 
    public function setAcessorio($acessorio)
    {
        $this->acessorio = $acessorio;

        return $this;
    }

    /**
     * Get the value of universo
     */ 
    public function getUniverso()
    {
        return $this->universo;
    }

    /**
     * Set the value of universo
     *
     * @return  self
     */ 
    public function setUniverso($universo)
    {
        $this->universo = $universo;

        return $this;
    }
}