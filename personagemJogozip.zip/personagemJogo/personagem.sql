-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/11/2024 às 03:41
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `personagem`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `acessorios`
--

CREATE TABLE `acessorios` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `acessorios`
--

INSERT INTO `acessorios` (`id`, `nome`) VALUES
(1, 'Espada'),
(2, 'Machado'),
(3, 'Picareta'),
(4, 'Arma de fogo'),
(5, 'Escudo'),
(6, 'Cajado'),
(7, 'Varinha mágico'),
(8, 'Armaduras'),
(9, 'Adagas'),
(10, 'Lança'),
(11, 'Mochila mágica'),
(12, 'Foice'),
(13, 'Vara de pesca'),
(14, 'Sabre de luz');

-- --------------------------------------------------------

--
-- Estrutura para tabela `habilidades`
--

CREATE TABLE `habilidades` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `habilidades`
--

INSERT INTO `habilidades` (`id`, `nome`) VALUES
(1, 'Fogo'),
(2, 'Agua'),
(3, 'Voar'),
(4, 'Super força'),
(5, 'Ficar invisivel'),
(6, 'Telepata'),
(7, 'Imortal'),
(8, 'Super velocidade'),
(9, 'Choque'),
(10, 'Regeneração'),
(11, 'Teleporte'),
(12, 'Controlar mentes'),
(13, 'Magia'),
(14, 'Visão raio-x'),
(15, 'Se transformar em carro');

-- --------------------------------------------------------

--
-- Estrutura para tabela `personagens`
--

CREATE TABLE `personagens` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL,
  `idade` varchar(50) NOT NULL,
  `altura` int(11) NOT NULL,
  `peso` int(11) NOT NULL,
  `id_habilidades` int(11) NOT NULL,
  `id_universos` int(11) NOT NULL,
  `id_acessorios` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `personagens`
--

INSERT INTO `personagens` (`id`, `nome`, `idade`, `altura`, `peso`, `id_habilidades`, `id_universos`, `id_acessorios`) VALUES
(2, 'Luis Henrique', '18', 168, 58, 15, 9, 11);

-- --------------------------------------------------------

--
-- Estrutura para tabela `universos`
--

CREATE TABLE `universos` (
  `id` int(11) NOT NULL,
  `nome` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `universos`
--

INSERT INTO `universos` (`id`, `nome`) VALUES
(1, 'Marvel'),
(2, 'DC'),
(3, 'Star Wars'),
(4, 'Transformers'),
(5, 'Minecraft'),
(6, 'Semáforo Vila A'),
(7, 'Hogwarts'),
(8, 'The Walking Dead'),
(9, 'IFPR'),
(10, 'Supernatural'),
(11, 'La casa de papel'),
(12, 'Naruto'),
(13, 'Dragon Ball'),
(14, 'Demon Slayer'),
(15, 'Turma da mônica'),
(16, 'Roblox'),
(17, '?????');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `acessorios`
--
ALTER TABLE `acessorios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `habilidades`
--
ALTER TABLE `habilidades`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `personagens`
--
ALTER TABLE `personagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_habilidades` (`id_habilidades`),
  ADD KEY `fk_universos` (`id_universos`),
  ADD KEY `fk_acessorios` (`id_acessorios`);

--
-- Índices de tabela `universos`
--
ALTER TABLE `universos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `acessorios`
--
ALTER TABLE `acessorios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `habilidades`
--
ALTER TABLE `habilidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `personagens`
--
ALTER TABLE `personagens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `universos`
--
ALTER TABLE `universos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `personagens`
--
ALTER TABLE `personagens`
  ADD CONSTRAINT `fk_acessorios` FOREIGN KEY (`id_acessorios`) REFERENCES `acessorios` (`id`),
  ADD CONSTRAINT `fk_habilidades` FOREIGN KEY (`id_habilidades`) REFERENCES `habilidades` (`id`),
  ADD CONSTRAINT `fk_universos` FOREIGN KEY (`id_universos`) REFERENCES `universos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
