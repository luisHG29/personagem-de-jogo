<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Acessorio.php");

class AcessorioDao {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();        
    }

    public function list() {
        $sql = "SELECT * FROM acessorios";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        return $this->mapAcessorios($result);
    }

    private function mapAcessorios(array $result) {
        $acessorios = array();

        foreach($result as $reg) {
            $acessorio = new Acessorio();
            $acessorio->setId($reg['id']);
            $acessorio->setNome($reg['nome']);

            array_push($acessorios, $acessorio);
        }

        return $acessorios;
    }

}