<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Habilidade.php");

class HabilidadeDao {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();        
    }

    public function list() {
        $sql = "SELECT * FROM habilidades";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        return $this->mapHabilidades($result);
    }

    private function mapHabilidades(array $result) {
        $habilidades = array();

        foreach($result as $reg) {
            $habilidade = new Habilidade();
            $habilidade->setId($reg['id']);
            $habilidade->setNome($reg['nome']);

            array_push($habilidades, $habilidade);
        }

        return $habilidades;
    }

}