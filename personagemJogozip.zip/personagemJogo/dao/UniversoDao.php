<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Universo.php");

class UniversoDao {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();        
    }

    public function list() {
        $sql = "SELECT * FROM universos";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        return $this->mapUniversos($result);
    }

    private function mapUniversos(array $result) {
        $universos = array();

        foreach($result as $reg) {
            $universo = new Universo();
            $universo->setId($reg['id']);
            $universo->setNome($reg['nome']);

            array_push($universos, $universo);
        }

        return $universos;
    }

}