<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Personagem.php");

class PersonagemDao
{

    private $conn;

    public function __construct()
    {
        $this->conn = Connection::getConnection();
    }

    public function insert(Personagem $personagem)
    {
        $sql = "INSERT INTO personagens (nome, idade, altura, peso, id_habilidades,
         id_acessorios, id_universos)
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stm = $this->conn->prepare($sql);
        $stm->execute(array(
            $personagem->getNome(),
            $personagem->getIdade(),
            $personagem->getAltura(),
            $personagem->getPeso(),
            $personagem->getHabilidade()->getId(),
            $personagem->getAcessorio()->getId(),
            $personagem->getUniverso()->getId()
        ));
    }

    public function delete($id)
    {
        $sql = "DELETE FROM personagens WHERE id = ?";

        $stm = $this->conn->prepare($sql);
        $stm->execute(array($id));
    }

    public function update(Personagem $personagem)
    {
        $conn = Connection::getConnection();

        $sql = "UPDATE personagens SET nome = ?, idade = ?," .
            " altura = ?, peso = ?, id_habilidades = ?, id_acessorios = ?, id_universos = ?" .
            " WHERE id = ?";
        $stmt = $conn->prepare($sql);

        $stmt->execute([
            $personagem->getNome(),
            $personagem->getIdade(),
            $personagem->getAltura(),
            $personagem->getPeso(),
            $personagem->getHabilidade()->getId(),
            $personagem->getAcessorio()->getId(),
            $personagem->getUniverso()->getId(),
            $personagem->getId()
        ]);
    }

    public function list()
    {
        $sql = "SELECT p.*, h.nome habilidade_nome, a.nome acessorio_nome, u.nome universo_nome
                FROM personagens p
                JOIN habilidades h ON (h.id = p.id_habilidades)
                JOIN acessorios a ON (a.id = p.id_acessorios)
                JOIN universos u ON (u.id = p.id_universos)";

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();

        $filmes = $this->mapPersonagem($result);
        return $filmes;
    }

    public function findById(int $id)
    {
        $conn = Connection::getConnection();

        $sql = "SELECT p.*, h.nome habilidade_nome, a.nome acessorio_nome, u.nome universo_nome
                FROM personagens p
                JOIN habilidades h ON (h.id = p.id_habilidades)
                JOIN acessorios a ON (a.id = p.id_acessorios)
                JOIN universos u ON (u.id = p.id_universos)
                WHERE p.id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();

        //Criar o objeto Aluno
        $personagens = $this->mapPersonagem($result);

        if (count($personagens) == 1)
            return $personagens[0];
        elseif (count($personagens) == 0)
            return null;

        die("PersonagemDAO.findById - Erro: mais de um personagem" .
            " encontrado para o ID " . $id);
    }

    private function mapPersonagem(array $result)
    {
        $personagens = array();

        foreach ($result as $reg) {
            $personagem = new Personagem();
            $personagem->setId($reg['id']);
            $personagem->setNome($reg['nome']);
            $personagem->setIdade($reg['idade']);
            $personagem->setAltura($reg['altura']);
            $personagem->setPeso($reg['peso']);

            $habilidade = new Habilidade();
            $habilidade->setId($reg['id_habilidades']);
            $habilidade->setNome($reg['habilidade_nome']);

            $personagem->setHabilidade($habilidade);

            $acessorio = new Acessorio();
            $acessorio->setId($reg['id_acessorios']);
            $acessorio->setNome($reg['acessorio_nome']);

            $personagem->setAcessorio($acessorio);


            $universo = new Universo();
            $universo->setId($reg['id_universos']);
            $universo->setNome($reg['universo_nome']);

            $personagem->setUniverso($universo);

            array_push($personagens, $personagem);
        }

        return $personagens;
    }
}
