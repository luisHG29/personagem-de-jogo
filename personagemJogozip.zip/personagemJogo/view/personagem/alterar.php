<?php

include_once(__DIR__ . "/../../model/Personagem.php");
include_once(__DIR__ . "/../../model/Habilidade.php");
include_once(__DIR__ . "/../../model/Acessorio.php");
include_once(__DIR__ . "/../../model/Universo.php");
include_once(__DIR__ . "/../../controller/PersonagemController.php");

$msgErro = "";
$personagem = null;

$personagemCont = new PersonagemController();

if (isset($_POST['id'])) {
    //Capturando os dados do formulário
    $nome = trim($_POST['nome']) ? trim($_POST['nome']) : null;
    $idade = isset($_POST['idade']) && is_numeric($_POST['idade']) ? (int)$_POST['idade'] : null;
    $altura = isset($_POST['altura']) && is_numeric($_POST['altura']) ? (int)$_POST['altura'] : null;
    $peso = isset($_POST['peso']) && is_numeric($_POST['peso']) ? (int)$_POST['peso'] : null;
    $habilidade = $_POST['habilidade'];
    $acessorio = $_POST['acessorio'];
    $universo = $_POST['universo'];
    $idPersonagem = $_POST['id'];

    //Criando o objeto aluno para alterar
    $personagem = new Personagem();
    $personagem->setId(0);
    $personagem->setNome($nome);
    $personagem->setIdade($idade);
    $personagem->setAltura($altura);
    $personagem->setPeso($peso);

    if ($habilidade) {
        $habilidadeObj = new Habilidade();
        $habilidadeObj->setId($habilidade);
        $personagem->setHabilidade($habilidadeObj);
    } else
        $personagem->setHabilidade(null);

    if ($acessorio) {
        $acessorioObj = new Acessorio();
        $acessorioObj->setId($acessorio);
        $personagem->setAcessorio($acessorioObj);
    } else
        $personagem->setAcessorio(null);

    if ($universo) {
        $universoObj = new Universo();
        $universoObj->setId($universo);
        $personagem->setUniverso($universoObj);
    } else
        $personagem->setUniverso(null);

    $personagem->setId($idPersonagem);


    //Chamando a rotina do controller para alterar o personagem
    $erros = $personagemCont->alterar($personagem);

    if (count($erros) <= 0) {
        //Redirecionando para a listagem
        header("location: listar.php");
    } else {
        $msgErro = implode("<br>", $erros);
        //echo $msgErro;
    }
} else {
    //Rotina para carregar os dados do aluno
    $idPersonagem = 0;
    if (isset($_GET['id']))
        $idPersonagem = $_GET['id'];

    if ($idPersonagem) {
        //Carregar os dados e exibir o forumulário
        $personagem = $personagemCont->buscarPorId($idPersonagem);
    } else {
        echo "ID do personagem é inválido!<br>";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}



include("form.php");
