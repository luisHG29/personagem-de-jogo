<?php

//Buscar os cursos para exibir no select
include_once(__DIR__ . "/../../controller/HabilidadeController.php");
include_once(__DIR__ . "/../../controller/AcessorioController.php");
include_once(__DIR__ . "/../../controller/UniversoController.php");

$habilidadeCont = new HabilidadeController();
$habilidades = $habilidadeCont->listar();

$acessorioCont = new AcessorioController();
$acessorios = $acessorioCont->listar();

$universoCont = new UniversoController();
$universos = $universoCont->listar();


include_once(__DIR__ . "/../include/header.php");
?>

<h3>Cadastrar Personagem</h3>

<div class="row">
    <div class="col-6">
        <form id="formPersonagem" method="POST">

            <div>
                <label class="form-label" for="txtTitulo">Nome:</label>
                <input class="form-control" type="text" placeholder="Informe o título do personagem"
                    name="nome" id="txtNome" maxlength="70"
                    value="<?= $personagem != null ? $personagem->getNome() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="txtIdade">Idade:</label>
                <input class="form-control" type="text" placeholder="Informe a idade do personagem"
                    name="idade" id="txtIdade"
                    value="<?= $personagem != null ? $personagem->getIdade() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="txtAltura">Altura:</label>
                <input class="form-control" type="number" placeholder="Informe a altura do personagem em cm"
                    name="altura" id="txtAltura"
                    value="<?= $personagem != null ? $personagem->getAltura() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="txtAltura">Peso:</label>
                <input class="form-control" type="number" placeholder="Informe o peso do personagem em kg"
                    name="peso" id="txtPeso"
                    value="<?= $personagem != null ? $personagem->getPeso() : "" ?>">
            </div>

            <div>
                <label class="form-label" for="selHabilidade">Habilidade:</label>
                <select class="form-control" name="habilidade" id="selHabilidade">
                    <option value="">----Selecione----</option>

                    <?php foreach ($habilidades as $h): ?>
                        <option value="<?= $h->getId() ?>"
                            <?php if (
                                $personagem != null && $personagem->getHabilidade() != null &&
                                $personagem->getHabilidade()->getId() == $h->getId()
                            )
                                echo "selected"; ?>>
                            <?= $h->getNome() ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="form-label" for="selAcessorio">Acessório:</label>
                <select class="form-control" name="acessorio" id="selAcessorio">
                    <option value="">----Selecione----</option>

                    <?php foreach ($acessorios as $a): ?>
                        <option value="<?= $a->getId() ?>"
                            <?php if (
                                $personagem != null && $personagem->getAcessorio() != null &&
                                $personagem->getAcessorio()->getId() == $a->getId()
                            )
                                echo "selected"; ?>>
                            <?= $a->getNome() ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label class="form-label" for="selUniverso">Universo:</label>
                <select class="form-control" name="universo" id="selUniverso">
                    <option value="">----Selecione----</option>

                    <?php foreach ($universos as $u): ?>
                        <option value="<?= $u->getId() ?>"
                            <?php if (
                                $personagem != null && $personagem->getUniverso() != null &&
                                $personagem->getUniverso()->getId() == $u->getId()
                            )
                                echo "selected"; ?>>
                            <?= $u->getNome() ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="hidden" name="id"
                value="<?= $personagem != null ? $personagem->getId() : "" ?>">

            <div class="mt-3">
                <input class="btn btn-success btn-sm" type="submit" value="Gravar" />
                <a class="btn btn-outline-secondary btn-sm" href="listar.php">Voltar</a>
            </div>

        </form>
    </div>

    <div class="col-6">
        <?php if ($msgErro): ?>
            <div class="alert alert-danger">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>

</div>




<?php
include_once(__DIR__ . "/../include/footer.php");
?>