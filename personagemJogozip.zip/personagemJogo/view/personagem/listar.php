<?php 
//Carregando a lista de personagens
include_once(__DIR__ . "/../../controller/PersonagemController.php");

$personagemCont = new PersonagemController();
$personagens = $personagemCont->listar();

//Inclusão do HTML do header
include_once(__DIR__ . "/../include/header.php");
?>

<h2>Listagem de Personagens</h2>

<a href="inserir.php" class="btn btn-primary btn-sm">Inserir</a>

<table class="table table-dark table-striped table-bordered mt-2">
    <!-- Cabeçalho da tabela -->
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Idade</th>
        <th>Altura</th>
        <th>Peso</th>
        <th>Habilidade</th>
        <th>Acessório</th>
        <th>Universo</th>
        <th></th>
        <th></th>
    </tr> 

    <!-- Dados da tabela -->
    <?php foreach($personagens as $p): ?> 
        <tr>
            <td><?= $p->getId(); ?></td>
            <td><?= $p->getNome(); ?></td>
            <td><?= $p->getIdade(); ?></td>
            <td><?= $p->getAltura(); ?>cm</td>
            <td><?= $p->getPeso(); ?>kg</td>
            <td><?= $p->getHabilidade()->getNome(); ?></td>
            <td><?= $p->getAcessorio()->getNome(); ?></td>
            <td><?= $p->getUniverso()->getNome(); ?></td>
            <td>
                <a href="alterar.php?id=<?= $p->getId(); ?>" >
                    Editar
                </a>
            </td>
            <td>
                <a href="excluir.php?id=<?= $p->getId(); ?>"
                    onclick="return confirm('Confirma a exclusão do personagem?');">
                    Excluir
                </a>
            </td>
        </tr>
    <?php endforeach; ?> 

</table>

<?php
    include_once(__DIR__ . "/../include/footer.php");
?>
    

